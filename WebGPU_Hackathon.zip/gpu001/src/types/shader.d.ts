declare module '*.wgsl';
declare module '*.glsl';
declare module '*.vs';
declare module '*.fs';