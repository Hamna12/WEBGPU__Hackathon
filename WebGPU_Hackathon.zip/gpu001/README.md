# Step-by-Step WebGPU Graphics Programming (42) 
## Create a torus Wireframe

This is the source code for the 42th part of a series YouTube videos on step-by-step WebGPU graphics programming.

This sample WebGPU app sets up the framework for creating 3D surface charts.